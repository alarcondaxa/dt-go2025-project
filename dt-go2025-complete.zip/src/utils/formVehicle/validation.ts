import z from 'zod';

export const zodSchema = z.object({
  plate: z.string().min(1, 'Placa obrigatória').trim(),
  renavam: z.string().min(1, 'Renavam obrigatório').trim(),
});

export type BodyProtocol = z.infer<typeof zodSchema>;
