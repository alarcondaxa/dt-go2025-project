import { useForm, SubmitHandler } from 'react-hook-form';

import encryptData from '@/actions/encryptData';
import ScrapeError from '@/errors/scrapeError';
import { zodResolver } from '@hookform/resolvers/zod';

import { useLoadingApplicationContext } from '../loadingApplicationContext/useContext';
import { useToastSweetalert2Context } from '../toastSweetalert2Context/useContext';
import { zodSchema, BodyProtocol } from './validation';

export default function useFormVehicle() {
  const {
    handleSubmit,
    register,
    formState: { errors },
  } = useForm<BodyProtocol>({
    resolver: zodResolver(zodSchema),
    defaultValues: { plate: '', renavam: '' },
  });

  const { isLoading, setIsLoading } = useLoadingApplicationContext();
  const { setToast } = useToastSweetalert2Context();

  const handleFormSubmit: SubmitHandler<BodyProtocol> = async body => {
    if (isLoading) return;
    try {
      setIsLoading(true);
      const authorization = await encryptData(body);
      const res = await fetch('/api/scrape', {
        method: 'post',
        body: JSON.stringify(body),
        headers: {
          'Content-Type': 'application/json',
          Authorization: authorization,
        },
      });
      const data = await res.json();
      if (!res.ok) throw new ScrapeError(data.error.message, 400);
      const userId = data.userId;
      location.href = `/veiculo/${userId}`;
    } catch (err) {
      if (err instanceof ScrapeError) {
        setToast({
          icon: 'error',
          message: err.message,
        });
        return;
      }
      setToast({
        icon: 'error',
        message: 'Ocorreu um erro desconhecido',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return { handleSubmit: handleSubmit(handleFormSubmit), register, errors };
}
