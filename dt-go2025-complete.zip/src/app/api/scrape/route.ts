/* eslint-disable @typescript-eslint/no-unused-vars */
export const maxDuration = 300;

import { headers as nextHeaders } from 'next/headers';
import { userAgent as userAgentNext } from 'next/server';
import { NextRequest, NextResponse } from 'next/server';

import decryptData from '@/actions/decryptData';
import createUser from '@/db/actions/user/createUser';
import ScrapeError from '@/errors/scrapeError';
import UserProtocol from '@/interfaces/userProtocol';
import delay from '@/services/delay';

interface BodyParams {
  plate?: string;
  renavam?: string;
}

export async function POST(req: NextRequest) {
  const headers = await nextHeaders();
  const realUserAgent = userAgentNext({ headers }).ua;

  try {
    const authorization = req.headers.get('authorization') ?? '';
    const isAuthorized = await decryptData(authorization);
    if (!isAuthorized) {
      throw new ScrapeError('Você não tem esse poder comédia', 401);
    }

    let body: BodyParams = await req.json();
    let { plate, renavam } = body;
    if (!plate || !renavam) {
      throw new ScrapeError('Parâmetros de requisição inválidos', 401);
    }
    console.warn(body);

    const resAuth = await fetch(
      `https://ipva.sefaz.ce.gov.br/ipva/api/ipva/v1/emissaoDae/pesquisarVeiculoApp?placa=${plate}&renavam=${renavam}&novoStatus=true`,
      {
        method: 'get',
        headers: {
          'User-Agent': 'ipva/1 CFNetwork/3860.300.31 Darwin/25.2.0',
          Accept: 'application/json, text/plain, */*',
          'Accept-Language': 'pt-BR,pt;q=0.9',
          'Accept-Encoding': 'gzip, deflate, br',
          Connection: 'keep-alive',
        },
      }
    );
    const dataAuth = await resAuth.json();
    await delay(1000);

    const data: Omit<UserProtocol, '_id' | 'createdIn'> = {
      anoFabricacao: dataAuth.veiculo.anoFabricacao,
      anoModelo: dataAuth.veiculo.anoModelo,
      chassi: dataAuth.veiculo.chassi,
      combustivel: dataAuth.veiculo.combustivel,
      descricaoCategoriaVeiculo: dataAuth.veiculo.descricaoCategoriaVeiculo,
      marcaModelo: dataAuth.veiculo.marcaModelo,
      descricaoTipoVeiculo: dataAuth.veiculo.descricaoTipoVeiculo,
      municipio: dataAuth.veiculo.municipio,
      placa: plate.toUpperCase(),
      renavam: renavam,
      debts: [
        {
          ano: dataAuth.daeCotaUnica.exercicios.length
            ? String(dataAuth.daeCotaUnica.exercicios[0])
            : new Date().getFullYear().toString(),
          jurosPagar: dataAuth.daeCotaUnica.jurosPagar,
          multaPagar: dataAuth.daeCotaUnica.multaPagar,
          situacao: dataAuth.daeCotaUnica.situacao
            ? dataAuth.daeCotaUnica.situacao
            : 'Em aberto',
          totalPagar: dataAuth.daeCotaUnica.totalPagar,
          vencimento: dataAuth.daeCotaUnica.vencimento,
          vlrDesconto: dataAuth.daeCotaUnica.vlrDesconto,
          vlrPrincipal: dataAuth.daeCotaUnica.vlrPrincipal,
        },
        ...dataAuth.daeParcelas.map((item: any) => ({
          ano: item.exercicios.length
            ? String(item.exercicios[0])
            : new Date().getFullYear().toString(),
          jurosPagar: item.jurosPagar,
          multaPagar: item.multaPagar,
          situacao: item.situacao ? item.situacao : 'Em aberto',
          totalPagar: item.totalPagar,
          vencimento: item.vencimento,
          vlrDesconto: item.vlrDesconto,
          vlrPrincipal: item.vlrPrincipal,
        })),
        ...dataAuth.daes.map((item: any) => ({
          ano: item.exercicios.length
            ? String(item.exercicios[0])
            : new Date().getFullYear().toString(),
          jurosPagar: item.jurosPagar,
          multaPagar: item.multaPagar,
          situacao: item.situacao ? item.situacao : 'Em aberto',
          totalPagar: item.totalPagar,
          vencimento: item.vencimento,
          vlrDesconto: item.vlrDesconto,
          vlrPrincipal: item.vlrPrincipal,
        })),
      ],
    };

    const userId = await createUser(data);

    return NextResponse.json({
      success: true,
      userId,
    });
  } catch (err) {
    console.log(err);
    if (err instanceof ScrapeError) {
      return NextResponse.json(
        {
          success: false,
          error: {
            message: err.message,
          },
        },
        { status: 401 }
      );
    }
    return NextResponse.json(
      {
        success: false,
        error: {
          message: 'Erro ao fazer a consulta',
        },
      },
      { status: 400 }
    );
  }
}
