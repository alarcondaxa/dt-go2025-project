import { IoMdSearch } from 'react-icons/io';

import Insights from '@/components/admin/insights';
import FormVehicle from '@/components/forms/formVehicle';
import Header from '@/components/header';

export default function Page() {
  return (
    <>
      <Header />
      <main className='bg-white w-full max-w-[1400px] mx-auto flex flex-col p-6 min-h-screen'>
        <h1 className='text-0b7675 text-xl font-medium mb-5'>
          Consultar Veículo - IPVA, Multas e CRLV
        </h1>
        <div className='grid grid-cols-2 max-[1000px]:grid-cols-1 gap-10'>
          <FormVehicle />
          <div className='w-full flex items-center justify-center max-[1000px]:hidden'>
            <IoMdSearch size={150} fill='#dcdcdc' className='flex-none' />
          </div>
        </div>
      </main>
      <Header />
      <Insights page='home' />
    </>
  );
}
