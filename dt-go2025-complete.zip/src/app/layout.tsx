/* eslint-disable @typescript-eslint/no-unused-vars */
import type { Metadata } from 'next';
import { Poppins } from 'next/font/google';

import './globals.css';
import LoadingApplicationContextProvider from '@/utils/loadingApplicationContext/context';
import LoadingContextProvider from '@/utils/loadingContext/context';
import ToastSweetalert2ContextProvider from '@/utils/toastSweetalert2Context/context';

const fontPoppins = Poppins({
  weight: ['300', '400', '500', '600', '700', '800', '900'],
  subsets: ['latin'],
  style: 'normal',
  display: 'swap',
  variable: '--font-poppins',
});

export const metadata: Metadata = {
  title: 'Consultar Veículo - IPVA, Multas e CRLV | Detran CE',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang='pt-BR' suppressHydrationWarning>
      <head>
        <meta charSet='UTF-8' />
        <meta name='viewport' content='width=device-width, initial-scale=1.0' />
        <link
          rel='shortcut icon'
          href='/assets/favicon-82a1b5c91a9a6264ecd6eb42469bb281ab35e2c5d6b9836ba78f618b4dc58ef8.ico'
          type='image/x-icon'
          sizes='any'
        />
      </head>
      <body className='font-sans'>
        <ToastSweetalert2ContextProvider>
          <LoadingContextProvider>
            <LoadingApplicationContextProvider>
              {children}
            </LoadingApplicationContextProvider>
          </LoadingContextProvider>
        </ToastSweetalert2ContextProvider>
      </body>
    </html>
  );
}
