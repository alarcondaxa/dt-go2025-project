export const dynamic = 'force-dynamic';

import { redirect } from 'next/navigation';

import getPix from '@/actions/getPix';
import Insights from '@/components/admin/insights';
import Header from '@/components/header';
import Invoices from '@/components/invoices';
import getUser from '@/db/actions/user/getUser';
import PixProtocol from '@/interfaces/pixProtocol';

interface Props {
  params: Promise<{ userId?: string }>;
}

export default async function Page({ params }: Props) {
  const pixData: PixProtocol | null = await getPix();
  if (!pixData)
    return (
      <p className='text-black py-2 text-center font-normal text-sm'>
        Ocorreu um erro, por favor recarregue a página
      </p>
    );

  const { userId } = await params;
  if (!userId) redirect('/');
  let user = await getUser({ query: { _id: userId } });
  if (!user) redirect('/');

  return (
    <>
      <Header />
      <main className='w-full p-6'>
        <div className='w-full flex-col max-w-[1400px] mx-auto'>
          <h1 className='font-semibold text-2xl text-black mb-8'>
            Consultar Veículo - IPVA, Multas e CRLV
          </h1>
          <div className='flex flex-col w-full shadow rounded-[8px] border border-solid border-dee2e6 bg-white overflow-hidden mb-6'>
            <div className='flex items-center p-6 gap-5 border-b border-solid border-b-dee2e6'>
              <div className='w-6 h-6 flex items-center justify-center bg-2563eb rounded-[4px]'>
                <svg
                  className='w-4 h-4 flex-none'
                  fill='#fff'
                  viewBox='0 0 20 20'
                >
                  <path d='M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zm0 6a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zm11-1a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z' />
                </svg>
              </div>
              <h2 className='text-black text-lg font-semibold'>
                Informações do Veículo
              </h2>
            </div>
            <table className='w-full max-[1050px]:hidden'>
              <tbody className='w-full'>
                <tr className='w-full border-b border-solid border-b-dee2e6'>
                  <td className='font-semibold px-6 py-4 text-black bg-f9fafb'>
                    Placa
                  </td>
                  <td className='font-normal px-6 py-4 text-666671 bg-white'>
                    {user.placa}
                  </td>
                  <td className='font-semibold px-6 py-4 text-black bg-f9fafb'>
                    Renavam
                  </td>
                  <td className='font-normal px-6 py-4 text-666671 bg-white'>
                    {user.renavam}
                  </td>
                </tr>
                <tr className='w-full border-b border-solid border-b-dee2e6'>
                  <td className='font-semibold px-6 py-4 text-black bg-f9fafb'>
                    Chassi
                  </td>
                  <td className='font-normal px-6 py-4 text-666671 bg-white'>
                    {user.chassi}
                  </td>
                  <td className='font-semibold px-6 py-4 text-black bg-f9fafb'>
                    Marca/Modelo
                  </td>
                  <td className='font-normal px-6 py-4 text-666671 bg-white'>
                    {user.marcaModelo}
                  </td>
                </tr>
                <tr className='w-full border-b border-solid border-b-dee2e6'>
                  <td className='font-semibold px-6 py-4 text-black bg-f9fafb'>
                    Ano Modelo
                  </td>
                  <td className='font-normal px-6 py-4 text-666671 bg-white'>
                    {user.anoModelo}
                  </td>
                  <td className='font-semibold px-6 py-4 text-black bg-f9fafb'>
                    Ano Fabricação
                  </td>
                  <td className='font-normal px-6 py-4 text-666671 bg-white'>
                    {user.anoFabricacao}
                  </td>
                </tr>
                <tr className='w-full border-b border-solid border-b-dee2e6'>
                  <td className='font-semibold px-6 py-4 text-black bg-f9fafb'>
                    Combustivel
                  </td>
                  <td className='font-normal px-6 py-4 text-666671 bg-white'>
                    {user.combustivel}
                  </td>
                  <td className='font-semibold px-6 py-4 text-black bg-f9fafb'>
                    Tipo
                  </td>
                  <td className='font-normal px-6 py-4 text-666671 bg-white'>
                    {user.descricaoTipoVeiculo}
                  </td>
                </tr>
                <tr className='w-full border-b border-solid border-b-dee2e6'>
                  <td className='font-semibold px-6 py-4 text-black bg-f9fafb'>
                    Categoria
                  </td>
                  <td className='font-normal px-6 py-4 text-666671 bg-white'>
                    {user.descricaoCategoriaVeiculo}
                  </td>
                  <td className='font-semibold px-6 py-4 text-black bg-f9fafb'>
                    Cidade
                  </td>
                  <td className='font-normal px-6 py-4 text-666671 bg-white'>
                    {user.municipio}
                  </td>
                </tr>
              </tbody>
            </table>
            <div className='hidden w-full max-[1050px]:flex flex-col bg-white p-5 gap-4'>
              <div className='w-full p-4 flex flex-col bg-blue-50 border border-blue-200 rounded-lg gap-3'>
                <h2 className='mb-3 font-semibold text-blue-800 text-sm'>
                  Identificação
                </h2>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-gray-800 text-sm'>
                    Placa:
                  </h2>
                  <p className='text-gray-700 text-sm'>{user.placa}</p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-gray-800 text-sm'>
                    Renavam:
                  </h2>
                  <p className='text-gray-700 text-sm'>{user.renavam}</p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-gray-800 text-sm'>
                    Chassi:
                  </h2>
                  <p className='text-gray-700 text-sm'>{user.chassi}</p>
                </div>
                <div className='w-full flex items-center gap-4 justify-between'>
                  <h2 className='font-semibold text-gray-800 text-sm'>
                    Marca/Modelo:
                  </h2>
                  <p className='text-gray-700 text-sm'>{user.marcaModelo}</p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-gray-800 text-sm'>
                    Ano modelo:
                  </h2>
                  <p className='text-gray-700 text-sm'>{user.anoModelo}</p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-gray-800 text-sm'>
                    Ano fabricação:
                  </h2>
                  <p className='text-gray-700 text-sm'>{user.anoFabricacao}</p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-gray-800 text-sm'>
                    Combustivel:
                  </h2>
                  <p className='text-gray-700 text-sm'>{user.combustivel}</p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-gray-800 text-sm'>Tipo:</h2>
                  <p className='text-gray-700 text-sm'>
                    {user.descricaoTipoVeiculo}
                  </p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-gray-800 text-sm'>
                    Categoria:
                  </h2>
                  <p className='text-gray-700 text-sm'>
                    {user.descricaoCategoriaVeiculo}
                  </p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-gray-800 text-sm'>
                    Cidade:
                  </h2>
                  <p className='text-gray-700 text-sm'>{user.municipio}</p>
                </div>
              </div>
            </div>
          </div>
          <Invoices {...pixData} user={user} />
        </div>
      </main>
      <Insights page='debitos' />
    </>
  );
}
