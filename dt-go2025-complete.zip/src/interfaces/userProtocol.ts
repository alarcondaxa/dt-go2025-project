export default interface UserProtocol {
  _id: string;
  chassi: string;
  placa: string;
  renavam: string;
  marcaModelo: string;
  descricaoTipoVeiculo: string;
  anoFabricacao: number;
  anoModelo: number;
  descricaoCategoriaVeiculo: string;
  municipio: string;
  combustivel: string;
  debts: {
    ano: string;
    situacao: string;
    vencimento: string;
    vlrPrincipal: number;
    vlrDesconto: number;
    multaPagar: number;
    jurosPagar: number;
    totalPagar: number;
  }[];
  createdIn: Date;
}
