import Image from 'next/image';

export default function Header() {
  return (
    <header className='w-full h-[120px] px-6 flex items-center justify-between bg-header-gradient max-[750px]:justify-center'>
      <Image src='/assets/svgs/logo.svg' width={450} height={65} alt='img' />
      <h2 className='uppercase text-white text-[35px] font-bold text-right max-[750px]:hidden'>
        Central de Serviços
      </h2>
    </header>
  );
}
