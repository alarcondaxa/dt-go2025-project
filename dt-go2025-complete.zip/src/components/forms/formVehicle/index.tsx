'use client';

import { twMerge } from 'tailwind-merge';

import useFormVehicle from '@/utils/formVehicle/useFormVehicle';

import Input from './input';

interface Props {
  className?: string;
}

export default function FormVehicle({ className }: Props) {
  const { handleSubmit, register, errors } = useFormVehicle();

  return (
    <form
      className={twMerge(
        'w-full max-w-[700px] flex flex-col bg-f6f6f9 p-6 rounded-3xl',
        className
      )}
      onSubmit={handleSubmit}
    >
      <h1 className='text-6f7482 font-semibold text-xl mb-5'>
        Insira a Placa e o Renavam do veículo para realizar a consulta
      </h1>
      <Input
        name='plate'
        register={register}
        errors={errors}
        label='Placa'
        className='mb-5'
      />
      <Input
        name='renavam'
        register={register}
        errors={errors}
        label='Renavam'
        className='mb-8'
      />
      <button
        type='submit'
        className='w-full bg-0b7675 rounded-[18px] flex items-center justify-center h-12 text-white text-sm font-medium'
      >
        Consultar
      </button>
    </form>
  );
}
