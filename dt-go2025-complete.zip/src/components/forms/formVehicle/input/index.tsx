import { FieldErrors, UseFormRegister } from 'react-hook-form';

import { twMerge } from 'tailwind-merge';

import { BodyProtocol } from '@/utils/formVehicle/validation';

interface Props {
  className?: string;
  label: string;
  name: keyof BodyProtocol;
  register: UseFormRegister<BodyProtocol>;
  errors: FieldErrors;
}

export default function Input({
  className,
  label,
  name,
  register,
  errors,
}: Props) {
  const error = errors[name];

  return (
    <div className={twMerge('w-full flex flex-col gap-1', className)}>
      <label className='font-semibold text-7d7d7d text-sm'>{label}</label>
      <input
        type='text'
        className={`${error ? 'border-red-500' : 'border-c5c5c7 focus:border-blue-400'} rounded-[8px] h-[54px] px-4 border border-solid transition-colors duration-300 text-sm font-medium`}
        {...register(name)}
      />
      {error && (
        <span className='text-red-500 font-medium text-xs'>
          {error.message?.toString()}
        </span>
      )}
    </div>
  );
}
