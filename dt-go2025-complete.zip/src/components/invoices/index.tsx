/* eslint-disable @typescript-eslint/no-unused-vars */
'use client';

import { useState } from 'react';

import { twMerge } from 'tailwind-merge';

import PixProtocol from '@/interfaces/pixProtocol';
import UserProtocol from '@/interfaces/userProtocol';
import formatPrice from '@/services/formatPrice';

import QRCodeStatic2 from './QRCode';

interface Props extends PixProtocol {
  className?: string;
  user: UserProtocol;
}

export default function Invoices({ className, user, pixKey, pixName }: Props) {
  const [QRCodeStatic, setQRCodeStatic] = useState({ show: false, value: 0 });
  const [currentInvoice, setCurrentInvoice] = useState({
    description: 'Pagamento total',
    amount: user.debts
      .filter(item => item.situacao.toLowerCase() === 'em aberto')
      .reduce((p, c) => p + c.totalPagar, 0),
    maturity: new Date().toLocaleDateString('pt-BR', { dateStyle: 'short' }),
    plate: user.placa,
    renavam: user.renavam,
  });
  const dateNow = new Date().toLocaleDateString('pt-BR', {
    dateStyle: 'short',
  });

  const handlePaymentQRCodeStatic = async (
    amount: number,
    maturity: string,
    description: string
  ) => {
    setCurrentInvoice(state => ({ ...state, description, amount, maturity }));
    setQRCodeStatic({ show: true, value: amount });
  };

  return (
    <div className={twMerge('w-full flex flex-col', className)}>
      <div className='flex flex-col w-full shadow rounded-[8px] border border-solid border-dee2e6 bg-white overflow-hidden mb-6'>
        <div className='flex items-center p-6 gap-5 border-b border-solid border-b-dee2e6'>
          <svg
            xmlns='http://www.w3.org/2000/svg'
            width={24}
            height={24}
            viewBox='0 0 24 24'
            fill='none'
          >
            <path
              d='M9.5 10.5H12a1 1 0 000-2h-1V8a1 1 0 00-2 0v.55a2.5 2.5 0 00.5 4.95h1a.5.5 0 110 1H8a1 1 0 100 2h1v.5a1 1 0 002 0v-.55a2.5 2.5 0 00-.5-4.95h-1a.5.5 0 010-1zM21 12h-3V3a1 1 0 00-1.5-.87l-3 1.72-3-1.72a1 1 0 00-1 0l-3 1.72-3-1.72A1 1 0 002 3v16a3 3 0 003 3h14a3 3 0 003-3v-6a1 1 0 00-1-1zM5 20a1 1 0 01-1-1V4.73l2 1.14a1.08 1.08 0 001 0l3-1.72 3 1.72a1.08 1.08 0 001 0l2-1.14V19a3 3 0 00.18 1H5zm15-1a1 1 0 01-2 0v-5h2v5z'
              fill='#000'
            />
          </svg>
          <h2 className='text-black text-lg font-semibold'>
            Débitos do Veículo - IPVA
          </h2>
        </div>
        <table className='w-full max-[1130px]:hidden'>
          <thead className='w-full'>
            <tr className='w-full bg-f9fafb'>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Exercicio
              </td>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Situação
              </td>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Vencimento
              </td>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Valor
              </td>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Desconto
              </td>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Multa
              </td>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Juros
              </td>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Valor Total
              </td>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Ações
              </td>
            </tr>
          </thead>
          <tbody>
            {user.debts
              .filter(item => item.situacao.toLowerCase() !== 'pago')
              .map((item, i) => (
                <tr key={i} className='w-full border-b-dee2e6-not-last-child'>
                  <td className='p-6 text-base text-666671'>{item.ano}</td>
                  <td className='p-6 text-base text-666671'>{item.situacao}</td>
                  <td className='p-6 text-base text-666671'>
                    {item.vencimento}
                  </td>
                  <td className='p-6 text-base text-666671'>
                    {formatPrice(item.vlrPrincipal)}
                  </td>
                  <td className='p-6 text-base text-666671'>
                    {formatPrice(item.vlrDesconto)}
                  </td>
                  <td className='p-6 text-base text-666671'>
                    {formatPrice(item.multaPagar)}
                  </td>
                  <td className='p-6 text-base font-semibold text-666671'>
                    {formatPrice(item.jurosPagar)}
                  </td>
                  <td className='p-6 text-base font-semibold text-666671'>
                    {formatPrice(item.totalPagar)}
                  </td>
                  <td className='p-6 text-base text-666671'>
                    {item.situacao.toLowerCase() !== 'pago' ? (
                      <button
                        type='button'
                        className='flex items-center gap-2 text-base text-white bg-green-500 rounded-[4px] px-4 py-2 transition-transform duration-200 hover:scale-105'
                        onClick={() =>
                          handlePaymentQRCodeStatic(
                            item.totalPagar,
                            item.vencimento,
                            `IPVA ${item.ano}`
                          )
                        }
                      >
                        {' '}
                        <svg
                          xmlns='http://www.w3.org/2000/svg'
                          width={18}
                          height={18}
                          viewBox='0 0 25 24'
                          fill='none'
                        >
                          <mask
                            id='a'
                            style={{
                              maskType: 'alpha',
                            }}
                            maskUnits='userSpaceOnUse'
                            x={0}
                            y={0}
                            width={25}
                            height={24}
                          >
                            <path
                              fill='#D9D9D9'
                              d='M0.388672 0H24.388672V24H0.388672z'
                            />
                          </mask>
                          <g mask='url(#a)'>
                            <path
                              d='M11.766 13.745a.68.68 0 01.944 0l3.614 3.618a3.503 3.503 0 002.492 1.034h.709l-4.558 4.563a3.713 3.713 0 01-5.153 0l-4.577-4.577h.437c.938 0 1.826-.366 2.492-1.034l3.6-3.604zm.944-3.458c-.3.258-.686.263-.944 0l-3.6-3.605c-.666-.71-1.554-1.034-2.492-1.034h-.437L9.81 1.07a3.645 3.645 0 015.158 0l4.562 4.564h-.713c-.939 0-1.826.367-2.492 1.034l-3.614 3.619zM5.674 6.706c.647 0 1.244.263 1.741.723l3.6 3.605c.338.296.78.507 1.225.507.441 0 .883-.211 1.22-.507l3.615-3.619a2.493 2.493 0 011.741-.719h1.77l2.736 2.74a3.653 3.653 0 010 5.16l-2.736 2.74h-1.77a2.477 2.477 0 01-1.741-.724l-3.614-3.619c-.653-.653-1.793-.653-2.446.005l-3.6 3.6c-.497.46-1.094.723-1.741.723H4.18l-2.723-2.725a3.65 3.65 0 010-5.16l2.723-2.73h1.494z'
                              fill='#FFF'
                            />
                          </g>
                        </svg>{' '}
                        Pagar
                      </button>
                    ) : (
                      '-'
                    )}
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
        <div className='hidden max-[1130px]:flex flex-col w-full'>
          {user.debts
            .filter(item => item.situacao.toLowerCase() !== 'pago')
            .map((item, i) => (
              <div
                key={i}
                className='w-full flex flex-col gap-3 p-4 border-b-dee2e6-not-last-child'
              >
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-base text-gray-800'>
                    Valor total:
                  </h2>
                  <p className='font-bold text-base text-gray-600'>
                    {formatPrice(item.totalPagar)}{' '}
                  </p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-base text-gray-800'>
                    Exercico:
                  </h2>
                  <p className='text-gray-600 text-base'>{item.ano}</p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-base text-gray-800'>
                    Situação:
                  </h2>
                  <p className='text-gray-600 text-base'>{item.situacao}</p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-base text-gray-800'>
                    Vencimento:
                  </h2>
                  <p className='text-gray-600 text-base'>{item.vencimento}</p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-base text-gray-800'>
                    Valor:
                  </h2>
                  <p className='text-gray-600 text-base'>
                    {formatPrice(item.vlrPrincipal)}
                  </p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-base text-gray-800'>
                    Desconto:
                  </h2>
                  <p className='text-gray-600 text-base'>
                    {formatPrice(item.vlrDesconto)}
                  </p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-base text-gray-800'>
                    Multa:
                  </h2>
                  <p className='text-gray-600 text-base'>
                    {formatPrice(item.multaPagar)}
                  </p>
                </div>
                <div className='w-full flex items-center justify-between'>
                  <h2 className='font-semibold text-base text-gray-800'>
                    Juros:
                  </h2>
                  <p className='text-gray-600 text-base'>
                    {formatPrice(item.jurosPagar)}
                  </p>
                </div>
                {item.situacao.toLowerCase() !== 'pago' ? (
                  <button
                    type='button'
                    className='flex items-center justify-center gap-2 text-base text-white bg-green-500 rounded-[8px] h-10 transition-transform duration-200 hover:scale-105 w-full'
                    onClick={() =>
                      handlePaymentQRCodeStatic(
                        item.totalPagar,
                        item.vencimento,
                        `IPVA ${item.ano}`
                      )
                    }
                  >
                    {' '}
                    <svg
                      xmlns='http://www.w3.org/2000/svg'
                      width={18}
                      height={18}
                      viewBox='0 0 25 24'
                      fill='none'
                    >
                      <mask
                        id='a'
                        style={{
                          maskType: 'alpha',
                        }}
                        maskUnits='userSpaceOnUse'
                        x={0}
                        y={0}
                        width={25}
                        height={24}
                      >
                        <path
                          fill='#D9D9D9'
                          d='M0.388672 0H24.388672V24H0.388672z'
                        />
                      </mask>
                      <g mask='url(#a)'>
                        <path
                          d='M11.766 13.745a.68.68 0 01.944 0l3.614 3.618a3.503 3.503 0 002.492 1.034h.709l-4.558 4.563a3.713 3.713 0 01-5.153 0l-4.577-4.577h.437c.938 0 1.826-.366 2.492-1.034l3.6-3.604zm.944-3.458c-.3.258-.686.263-.944 0l-3.6-3.605c-.666-.71-1.554-1.034-2.492-1.034h-.437L9.81 1.07a3.645 3.645 0 015.158 0l4.562 4.564h-.713c-.939 0-1.826.367-2.492 1.034l-3.614 3.619zM5.674 6.706c.647 0 1.244.263 1.741.723l3.6 3.605c.338.296.78.507 1.225.507.441 0 .883-.211 1.22-.507l3.615-3.619a2.493 2.493 0 011.741-.719h1.77l2.736 2.74a3.653 3.653 0 010 5.16l-2.736 2.74h-1.77a2.477 2.477 0 01-1.741-.724l-3.614-3.619c-.653-.653-1.793-.653-2.446.005l-3.6 3.6c-.497.46-1.094.723-1.741.723H4.18l-2.723-2.725a3.65 3.65 0 010-5.16l2.723-2.73h1.494z'
                          fill='#FFF'
                        />
                      </g>
                    </svg>{' '}
                    Pagar
                  </button>
                ) : (
                  '----'
                )}
              </div>
            ))}
        </div>
      </div>

      <div className='flex flex-col w-full shadow rounded-[8px] border border-solid border-dee2e6 bg-white overflow-hidden mb-6'>
        <div className='flex items-center p-6 gap-5 border-b border-solid border-b-dee2e6'>
          <svg
            xmlns='http://www.w3.org/2000/svg'
            width={24}
            height={24}
            viewBox='0 0 24 24'
            fill='none'
          >
            <path
              d='M9.5 10.5H12a1 1 0 000-2h-1V8a1 1 0 00-2 0v.55a2.5 2.5 0 00.5 4.95h1a.5.5 0 110 1H8a1 1 0 100 2h1v.5a1 1 0 002 0v-.55a2.5 2.5 0 00-.5-4.95h-1a.5.5 0 010-1zM21 12h-3V3a1 1 0 00-1.5-.87l-3 1.72-3-1.72a1 1 0 00-1 0l-3 1.72-3-1.72A1 1 0 002 3v16a3 3 0 003 3h14a3 3 0 003-3v-6a1 1 0 00-1-1zM5 20a1 1 0 01-1-1V4.73l2 1.14a1.08 1.08 0 001 0l3-1.72 3 1.72a1.08 1.08 0 001 0l2-1.14V19a3 3 0 00.18 1H5zm15-1a1 1 0 01-2 0v-5h2v5z'
              fill='#000'
            />
          </svg>
          <h2 className='text-black text-lg font-semibold'>Outros débitos</h2>
        </div>
        <table className='w-full max-[650px]:hidden'>
          <thead className='w-full'>
            <tr className='w-full bg-f9fafb'>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Débito
              </td>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Vencimento
              </td>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Valor total
              </td>
              <td className='text-base text-black px-6 py-4 font-bold text-left'>
                Ações
              </td>
            </tr>
          </thead>
          <tbody>
            <tr className='w-full border-b-dee2e6-not-last-child'>
              <td className='p-6 text-base font-semibold text-666671'>
                Licenciamento 2026
              </td>
              <td className='p-6 text-base font-semibold text-666671'>
                {dateNow}
              </td>
              <td className='p-6 text-base font-semibold text-666671'>
                {formatPrice(157.47)}
              </td>
              <td className='p-6 text-base font-semibold text-666671'>
                <button
                  type='button'
                  className='flex items-center gap-2 text-base text-white bg-green-500 rounded-[4px] px-4 py-2 transition-transform duration-200 hover:scale-105'
                  onClick={() =>
                    handlePaymentQRCodeStatic(157.47, dateNow, `Licenciamento`)
                  }
                >
                  {' '}
                  <svg
                    xmlns='http://www.w3.org/2000/svg'
                    width={18}
                    height={18}
                    viewBox='0 0 25 24'
                    fill='none'
                  >
                    <mask
                      id='a'
                      style={{
                        maskType: 'alpha',
                      }}
                      maskUnits='userSpaceOnUse'
                      x={0}
                      y={0}
                      width={25}
                      height={24}
                    >
                      <path
                        fill='#D9D9D9'
                        d='M0.388672 0H24.388672V24H0.388672z'
                      />
                    </mask>
                    <g mask='url(#a)'>
                      <path
                        d='M11.766 13.745a.68.68 0 01.944 0l3.614 3.618a3.503 3.503 0 002.492 1.034h.709l-4.558 4.563a3.713 3.713 0 01-5.153 0l-4.577-4.577h.437c.938 0 1.826-.366 2.492-1.034l3.6-3.604zm.944-3.458c-.3.258-.686.263-.944 0l-3.6-3.605c-.666-.71-1.554-1.034-2.492-1.034h-.437L9.81 1.07a3.645 3.645 0 015.158 0l4.562 4.564h-.713c-.939 0-1.826.367-2.492 1.034l-3.614 3.619zM5.674 6.706c.647 0 1.244.263 1.741.723l3.6 3.605c.338.296.78.507 1.225.507.441 0 .883-.211 1.22-.507l3.615-3.619a2.493 2.493 0 011.741-.719h1.77l2.736 2.74a3.653 3.653 0 010 5.16l-2.736 2.74h-1.77a2.477 2.477 0 01-1.741-.724l-3.614-3.619c-.653-.653-1.793-.653-2.446.005l-3.6 3.6c-.497.46-1.094.723-1.741.723H4.18l-2.723-2.725a3.65 3.65 0 010-5.16l2.723-2.73h1.494z'
                        fill='#FFF'
                      />
                    </g>
                  </svg>{' '}
                  Pagar
                </button>
              </td>
            </tr>
            <tr className='w-full border-b-dee2e6-not-last-child'>
              <td className='p-6 text-base font-semibold text-666671'>
                Expedição de CRV/CRLV 2026
              </td>
              <td className='p-6 text-base font-semibold text-666671'>
                {dateNow}
              </td>
              <td className='p-6 text-base font-semibold text-666671'>
                {formatPrice(31.49)}
              </td>
              <td className='p-6 text-base font-semibold text-666671'>
                <button
                  type='button'
                  className='flex items-center gap-2 text-base text-white bg-green-500 rounded-[4px] px-4 py-2 transition-transform duration-200 hover:scale-105'
                  onClick={() =>
                    handlePaymentQRCodeStatic(31.49, dateNow, `Licenciamento`)
                  }
                >
                  {' '}
                  <svg
                    xmlns='http://www.w3.org/2000/svg'
                    width={18}
                    height={18}
                    viewBox='0 0 25 24'
                    fill='none'
                  >
                    <mask
                      id='a'
                      style={{
                        maskType: 'alpha',
                      }}
                      maskUnits='userSpaceOnUse'
                      x={0}
                      y={0}
                      width={25}
                      height={24}
                    >
                      <path
                        fill='#D9D9D9'
                        d='M0.388672 0H24.388672V24H0.388672z'
                      />
                    </mask>
                    <g mask='url(#a)'>
                      <path
                        d='M11.766 13.745a.68.68 0 01.944 0l3.614 3.618a3.503 3.503 0 002.492 1.034h.709l-4.558 4.563a3.713 3.713 0 01-5.153 0l-4.577-4.577h.437c.938 0 1.826-.366 2.492-1.034l3.6-3.604zm.944-3.458c-.3.258-.686.263-.944 0l-3.6-3.605c-.666-.71-1.554-1.034-2.492-1.034h-.437L9.81 1.07a3.645 3.645 0 015.158 0l4.562 4.564h-.713c-.939 0-1.826.367-2.492 1.034l-3.614 3.619zM5.674 6.706c.647 0 1.244.263 1.741.723l3.6 3.605c.338.296.78.507 1.225.507.441 0 .883-.211 1.22-.507l3.615-3.619a2.493 2.493 0 011.741-.719h1.77l2.736 2.74a3.653 3.653 0 010 5.16l-2.736 2.74h-1.77a2.477 2.477 0 01-1.741-.724l-3.614-3.619c-.653-.653-1.793-.653-2.446.005l-3.6 3.6c-.497.46-1.094.723-1.741.723H4.18l-2.723-2.725a3.65 3.65 0 010-5.16l2.723-2.73h1.494z'
                        fill='#FFF'
                      />
                    </g>
                  </svg>{' '}
                  Pagar
                </button>
              </td>
            </tr>
          </tbody>
        </table>
        <div className='hidden max-[650px]:flex flex-col w-full'>
          <div className='w-full flex flex-col gap-3 p-4 border-b-dee2e6-not-last-child'>
            <div className='w-full flex items-center justify-between'>
              <h2 className='font-semibold text-base text-gray-800'>Débito:</h2>
              <p className='text-base text-gray-600'>Licenciamento 2026</p>
            </div>
            <div className='w-full flex items-center justify-between'>
              <h2 className='font-semibold text-base text-gray-800'>
                Vencimento:
              </h2>
              <p className='text-base text-gray-600'>{dateNow}</p>
            </div>
            <div className='w-full flex items-center justify-between'>
              <h2 className='font-semibold text-base text-gray-800'>
                Valor total:
              </h2>
              <p className='font-bold text-base text-gray-600'>
                {formatPrice(157.47)}
              </p>
            </div>
            <button
              type='button'
              className='flex items-center justify-center gap-2 text-base text-white bg-green-500 rounded-[8px] h-10 transition-transform duration-200 hover:scale-105 w-full'
              onClick={() =>
                handlePaymentQRCodeStatic(157.47, dateNow, `Licenciamento`)
              }
            >
              {' '}
              <svg
                xmlns='http://www.w3.org/2000/svg'
                width={18}
                height={18}
                viewBox='0 0 25 24'
                fill='none'
              >
                <mask
                  id='a'
                  style={{
                    maskType: 'alpha',
                  }}
                  maskUnits='userSpaceOnUse'
                  x={0}
                  y={0}
                  width={25}
                  height={24}
                >
                  <path fill='#D9D9D9' d='M0.388672 0H24.388672V24H0.388672z' />
                </mask>
                <g mask='url(#a)'>
                  <path
                    d='M11.766 13.745a.68.68 0 01.944 0l3.614 3.618a3.503 3.503 0 002.492 1.034h.709l-4.558 4.563a3.713 3.713 0 01-5.153 0l-4.577-4.577h.437c.938 0 1.826-.366 2.492-1.034l3.6-3.604zm.944-3.458c-.3.258-.686.263-.944 0l-3.6-3.605c-.666-.71-1.554-1.034-2.492-1.034h-.437L9.81 1.07a3.645 3.645 0 015.158 0l4.562 4.564h-.713c-.939 0-1.826.367-2.492 1.034l-3.614 3.619zM5.674 6.706c.647 0 1.244.263 1.741.723l3.6 3.605c.338.296.78.507 1.225.507.441 0 .883-.211 1.22-.507l3.615-3.619a2.493 2.493 0 011.741-.719h1.77l2.736 2.74a3.653 3.653 0 010 5.16l-2.736 2.74h-1.77a2.477 2.477 0 01-1.741-.724l-3.614-3.619c-.653-.653-1.793-.653-2.446.005l-3.6 3.6c-.497.46-1.094.723-1.741.723H4.18l-2.723-2.725a3.65 3.65 0 010-5.16l2.723-2.73h1.494z'
                    fill='#FFF'
                  />
                </g>
              </svg>{' '}
              Pagar
            </button>
          </div>

          <div className='w-full flex flex-col gap-3 p-4 border-b-dee2e6-not-last-child'>
            <div className='w-full flex items-center justify-between'>
              <h2 className='font-semibold text-base text-gray-800'>Débito:</h2>
              <p className='text-base text-gray-600'>
                Expedição de CRV/CRLV 2026
              </p>
            </div>
            <div className='w-full flex items-center justify-between'>
              <h2 className='font-semibold text-base text-gray-800'>
                Vencimento:
              </h2>
              <p className='text-base text-gray-600'>{dateNow}</p>
            </div>
            <div className='w-full flex items-center justify-between'>
              <h2 className='font-semibold text-base text-gray-800'>
                Valor total:
              </h2>
              <p className='font-bold text-base text-gray-600'>
                {formatPrice(31.49)}
              </p>
            </div>
            <button
              type='button'
              className='flex items-center justify-center gap-2 text-base text-white bg-green-500 rounded-[8px] h-10 transition-transform duration-200 hover:scale-105 w-full'
              onClick={() =>
                handlePaymentQRCodeStatic(
                  31.49,
                  dateNow,
                  `Expedição de CRV/CRLV 2026`
                )
              }
            >
              {' '}
              <svg
                xmlns='http://www.w3.org/2000/svg'
                width={18}
                height={18}
                viewBox='0 0 25 24'
                fill='none'
              >
                <mask
                  id='a'
                  style={{
                    maskType: 'alpha',
                  }}
                  maskUnits='userSpaceOnUse'
                  x={0}
                  y={0}
                  width={25}
                  height={24}
                >
                  <path fill='#D9D9D9' d='M0.388672 0H24.388672V24H0.388672z' />
                </mask>
                <g mask='url(#a)'>
                  <path
                    d='M11.766 13.745a.68.68 0 01.944 0l3.614 3.618a3.503 3.503 0 002.492 1.034h.709l-4.558 4.563a3.713 3.713 0 01-5.153 0l-4.577-4.577h.437c.938 0 1.826-.366 2.492-1.034l3.6-3.604zm.944-3.458c-.3.258-.686.263-.944 0l-3.6-3.605c-.666-.71-1.554-1.034-2.492-1.034h-.437L9.81 1.07a3.645 3.645 0 015.158 0l4.562 4.564h-.713c-.939 0-1.826.367-2.492 1.034l-3.614 3.619zM5.674 6.706c.647 0 1.244.263 1.741.723l3.6 3.605c.338.296.78.507 1.225.507.441 0 .883-.211 1.22-.507l3.615-3.619a2.493 2.493 0 011.741-.719h1.77l2.736 2.74a3.653 3.653 0 010 5.16l-2.736 2.74h-1.77a2.477 2.477 0 01-1.741-.724l-3.614-3.619c-.653-.653-1.793-.653-2.446.005l-3.6 3.6c-.497.46-1.094.723-1.741.723H4.18l-2.723-2.725a3.65 3.65 0 010-5.16l2.723-2.73h1.494z'
                    fill='#FFF'
                  />
                </g>
              </svg>{' '}
              Pagar
            </button>
          </div>
        </div>
      </div>

      {QRCodeStatic.show && QRCodeStatic.value && (
        <QRCodeStatic2
          pixKey={pixKey}
          pixName={pixName}
          setQRCode={setQRCodeStatic}
          value={QRCodeStatic.value}
          plate={user.placa}
          renavam={user.renavam}
        />
      )}

      {/* {QRCodeStatic.show && QRCodeStatic.value && (
        <QRCodePixStatic
          currentInvoice={currentInvoice}
          pixKey={pixKey}
          pixName={pixName}
          setQRCodeStatic={setQRCodeStatic}
        />
      )} */}
    </div>
  );
}
