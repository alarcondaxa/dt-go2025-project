'use client';

import Image from 'next/image';

import { Dispatch, SetStateAction } from 'react';
import { IoClose } from 'react-icons/io5';

import PixProtocol from '@/interfaces/pixProtocol';
import useQRCode from '@/utils/useQRCode';

interface Props extends PixProtocol {
  plate: string;
  renavam: string;
  value: number;
  setQRCode: Dispatch<SetStateAction<{ value: number; show: boolean }>>;
}

export default function QRCodeStatic2({
  pixKey,
  pixName,
  value,
  setQRCode,
  plate,
  renavam,
}: Props) {
  const { QRData, handleCopy } = useQRCode({
    pixKey,
    pixName,
    value,
    plate,
    renavam,
  });

  const handleClose = () => {
    setQRCode(state => ({ ...state, show: false }));
  };

  return (
    <div
      className='w-full h-screen fixed z-20 bg-0006 flex items-center justify-center inset-0 px-4'
      onClick={handleClose}
    >
      <div
        className='bg-white flex flex-col rounded overflow-hidden w-full max-w-[500px] max-h-[95vh]'
        onClick={event => event.stopPropagation()}
      >
        <div className='w-full bg-white p-4 flex items-center justify-between border-b border-b-gray-300 border-solid'>
          <span className='text-black font-normal text-base'>
            Pagamento por PIX
          </span>
          <button type='button' onClick={handleClose}>
            <IoClose size={22} fill='#555' />
          </button>
        </div>
        <div className='flex flex-col overflow-x-hidden overflow-y-auto p-4'>
          <h2 className='text-[15px] font-medium text-black pb-2 border-b-[#333] border-b border-solid w-full'>
            Pagamento
          </h2>
          <div className='w-full py-2 border-b-[#333] border-b border-solid flex items-center gap-2'>
            <div className='w-5 h-5 rounded-full flex-none bg-005394 text-white text-xs font-medium flex items-center justify-center leading-none'>
              1
            </div>
            <div className='flex flex-col'>
              <p className='text-sm font-medium text-black '>
                App do seu Banco
              </p>
              <p className='text-xs font-normal text-black '>
                Abra o app do seu banco e vá até o menu PIX
              </p>
            </div>
          </div>
          <div className='w-full py-2 border-b-[#333] border-b border-solid flex items-center gap-2'>
            <div className='w-5 h-5 rounded-full flex-none bg-005394 text-white text-xs font-medium flex items-center justify-center leading-none'>
              2
            </div>
            <div className='flex flex-col'>
              <p className='text-sm font-medium text-black '>PIX QR-CODE</p>
              <p className='text-xs font-normal text-black '>
                Escolha a opção para pagar com QR-CODE, aponte a câmera do
                celular para o QR-CODE abaixo ou copie o código pix abaixo e
                cole no seu aplicativo bancário na função (Copiar-Colar)
              </p>
            </div>
          </div>
          <div className='w-full py-2 border-b-[#333] border-b border-solid flex flex-col items-center justify-center mb-3'>
            <p className='text-sm font-medium text-black text-center'>
              Leia o QR Code:
            </p>
            {QRData.src && (
              <Image src={QRData.src} width={200} height={200} alt='qr-code' />
            )}
          </div>
          <div className='w-full bg-f1f1f1 p-2 truncate text-sm font-normal text-[#333] mb-3 flex-none'>
            {QRData.name}
          </div>
          <button
            type='button'
            onClick={handleCopy}
            className='w-full p-2 h-10 text-sm font-normal rounded flex-none bg-header-gradient text-white transition-colors duration-300'
          >
            Copiar código
          </button>
        </div>
      </div>
    </div>
  );
}
