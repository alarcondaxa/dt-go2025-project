import { Schema, model, models, type Document, Model } from 'mongoose';

import UserProtocol from '@/interfaces/userProtocol';

export interface UserDocumentProtocol
  extends Omit<UserProtocol, '_id'>,
    Document {}

const usersSchema = new Schema<UserDocumentProtocol>({
  chassi: { type: String, required: false, default: '' },
  placa: { type: String, required: false, default: '' },
  renavam: { type: String, required: false, default: '' },
  marcaModelo: { type: String, required: false, default: '' },
  descricaoTipoVeiculo: { type: String, required: false, default: '' },
  anoFabricacao: { type: Number, required: false, default: 0 },
  anoModelo: { type: Number, required: false, default: 0 },
  descricaoCategoriaVeiculo: { type: String, required: false, default: '' },
  municipio: { type: String, required: false, default: '' },
  combustivel: { type: String, required: false, default: '' },
  debts: [
    {
      ano: { type: String, required: false, default: '' },
      situacao: { type: String, required: false, default: '' },
      vencimento: { type: String, required: false, default: '' },
      vlrPrincipal: { type: Number, required: false, default: 0 },
      vlrDesconto: { type: Number, required: false, default: 0 },
      multaPagar: { type: Number, required: false, default: 0 },
      jurosPagar: { type: Number, required: false, default: 0 },
      totalPagar: { type: Number, required: false, default: 0 },
    },
  ],
  createdIn: {
    type: Date,
    required: false,
    default: Date.now,
    index: { expires: '24h' },
  },
});

const usersModel: Model<UserDocumentProtocol> =
  models.DTCEUsers || model<UserDocumentProtocol>('DTCEUsers', usersSchema);

export default usersModel;
