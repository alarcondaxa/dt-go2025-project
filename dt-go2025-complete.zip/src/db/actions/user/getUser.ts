'use server';

import { FilterQuery } from 'mongoose';

import usersModel, { UserDocumentProtocol } from '@/db/models/user';
import UserProtocol from '@/interfaces/userProtocol';

import connectDb from '../../connect';

interface Props {
  query: FilterQuery<UserDocumentProtocol>;
}

export default async function getUser({ query }: Props) {
  try {
    await connectDb();
    const res = await usersModel.findOne(query).sort({
      createdIn: -1,
    });
    if (!res) throw new Error('Usuário não encontrado');
    const data: UserProtocol = {
      _id: String(res._id),
      anoFabricacao: res.anoFabricacao,
      anoModelo: res.anoModelo,
      chassi: res.chassi,
      combustivel: res.combustivel,
      descricaoCategoriaVeiculo: res.descricaoCategoriaVeiculo,
      marcaModelo: res.marcaModelo,
      descricaoTipoVeiculo: res.descricaoTipoVeiculo,
      municipio: res.municipio,
      placa: res.placa,
      renavam: res.renavam,
      debts: res.debts.map(item => ({
        ano: item.ano,
        jurosPagar: item.jurosPagar,
        multaPagar: item.multaPagar,
        situacao: item.situacao,
        totalPagar: item.totalPagar,
        vencimento: item.vencimento,
        vlrDesconto: item.vlrDesconto,
        vlrPrincipal: item.vlrPrincipal,
      })),
      createdIn: res.createdIn,
    };
    return data;
  } catch (err) {
    console.log(err);
    return null;
  }
}
