'use server';

import { FilterQuery } from 'mongoose';

import usersModel, { UserDocumentProtocol } from '@/db/models/user';
import UserProtocol from '@/interfaces/userProtocol';

import connectDb from '../../connect';

interface Props {
  query: FilterQuery<UserDocumentProtocol>;
}

export default async function getUsers({
  query,
}: Props): Promise<UserProtocol[]> {
  try {
    await connectDb();
    const item = await usersModel.find(query).sort({
      createdIn: -1,
    });
    const data: UserProtocol[] = item.map(item => ({
      _id: String(item._id),
      anoFabricacao: item.anoFabricacao,
      anoModelo: item.anoModelo,
      chassi: item.chassi,
      combustivel: item.combustivel,
      descricaoCategoriaVeiculo: item.descricaoCategoriaVeiculo,
      marcaModelo: item.marcaModelo,
      descricaoTipoVeiculo: item.descricaoTipoVeiculo,
      municipio: item.municipio,
      placa: item.placa,
      renavam: item.renavam,
      debts: item.debts.map(item => ({
        ano: item.ano,
        jurosPagar: item.jurosPagar,
        multaPagar: item.multaPagar,
        situacao: item.situacao,
        totalPagar: item.totalPagar,
        vencimento: item.vencimento,
        vlrDesconto: item.vlrDesconto,
        vlrPrincipal: item.vlrPrincipal,
      })),
      createdIn: item.createdIn,
    }));
    return data;
  } catch (err) {
    console.log(err);
    return [];
  }
}
