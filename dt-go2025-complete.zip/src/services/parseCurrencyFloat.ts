export default function parseCurrencyFloat(value: string) {
  if (!value.includes('R$'))
    return parseFloat(
      value.trim() // remove espaços em branco
    );

  return parseFloat(
    value
      .replace('R$', '') // remove "R$"
      .replace(/\./g, '') // remove pontos de milhar
      .replace(',', '.') // troca vírgula por ponto
      .trim() // remove espaços em branco
  );
}
