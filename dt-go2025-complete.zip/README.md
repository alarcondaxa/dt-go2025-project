# DT-GO 2025 - Sistema de Consulta de Veículos

Aplicação web full-stack para consulta de informações de veículos (IPVA, Multas, CRLV) com painel administrativo integrado.

## 🎯 Funcionalidades

- **Consulta de Veículos**: Busca de informações de IPVA, multas e CRLV
- **Painel Administrativo**: Dashboard com gerenciamento de dados
- **Autenticação**: Sistema seguro com NextAuth
- **Integração de Pagamentos**: Suporte a múltiplos gateways de pagamento
- **Banco de Dados**: MongoDB Atlas para persistência de dados
- **Automação**: Puppeteer para web scraping com proteção anti-captcha

## 🚀 Tecnologias

- **Frontend**: Next.js 15.5.4, React 19, TypeScript, Tailwind CSS
- **Backend**: Next.js API Routes, NextAuth
- **Banco de Dados**: MongoDB
- **UI Components**: Radix UI, Recharts, SweetAlert2
- **Automação**: Puppeteer com plugins de stealth e reCAPTCHA
- **Validação**: Zod, React Hook Form

## 📋 Pré-requisitos

- Node.js 18+ ou superior
- npm, yarn, pnpm ou bun
- MongoDB Atlas (conta gratuita disponível)
- Variáveis de ambiente configuradas

## 🔧 Instalação Local

1. **Clone o repositório**
```bash
git clone https://github.com/seu-usuario/dt-go2025.git
cd dt-go2025
```

2. **Instale as dependências**
```bash
npm install
# ou
pnpm install
```

3. **Configure as variáveis de ambiente**
```bash
cp .env.example .env.local
```

Edite o arquivo `.env.local` com suas credenciais:
- MongoDB URL
- NextAuth secrets
- Credenciais de admin
- Chaves de API dos gateways de pagamento

4. **Execute o servidor de desenvolvimento**
```bash
npm run dev
```

Abra [http://localhost:3000](http://localhost:3000) no navegador.

## 🏗️ Estrutura do Projeto

```
src/
├── app/                 # Rotas e páginas Next.js
│   ├── admin/          # Painel administrativo
│   ├── api/            # API Routes
│   └── page.tsx        # Página inicial
├── components/         # Componentes React reutilizáveis
├── actions/            # Server actions
├── services/           # Serviços e integrações
├── db/                 # Configuração do banco de dados
├── middleware.ts       # Middleware de autenticação
└── utils/              # Funções utilitárias
```

## 📝 Variáveis de Ambiente

Veja o arquivo `.env.example` para a lista completa de variáveis necessárias:

| Variável | Descrição |
|----------|-----------|
| `MONGODB_URL` | URL de conexão do MongoDB Atlas |
| `SECRET` | Chave secreta da aplicação |
| `NEXTAUTH_URL` | URL base da aplicação |
| `AUTH_SECRET` | Chave secreta do NextAuth |
| `ADMIN_EMAIL` | Email do administrador |
| `ADMIN_PASSWORD` | Senha do administrador |
| `*_PAYMENT_SECRET` | Chaves de API dos gateways de pagamento |

## 🚀 Deploy na Vercel

1. **Push para GitHub**
```bash
git push origin main
```

2. **Conecte ao Vercel**
- Acesse [vercel.com](https://vercel.com)
- Clique em "New Project"
- Selecione o repositório GitHub
- Configure as variáveis de ambiente

3. **Deploy automático**
- Cada push para `main` fará deploy automático
- Vercel gerencia SSL, CDN e escalabilidade

## 🔐 Segurança

- ✅ Variáveis sensíveis em `.env.local` (não commitadas)
- ✅ NextAuth para autenticação segura
- ✅ Proteção CSRF e validação de entrada
- ✅ Puppeteer com plugins de stealth para evitar bloqueios

## 📦 Scripts Disponíveis

```bash
npm run dev      # Inicia servidor de desenvolvimento
npm run build    # Build para produção
npm start        # Inicia servidor de produção
npm run lint     # Executa ESLint
```

## 🐛 Troubleshooting

### Erro de conexão MongoDB
- Verifique se a URL está correta em `.env.local`
- Certifique-se de que seu IP está na whitelist do MongoDB Atlas

### Erro de autenticação
- Regenere o `AUTH_SECRET` com: `npx auth secret`
- Verifique se `NEXTAUTH_URL` está correto

### Erro de build
- Delete `node_modules` e `.next`
- Execute `npm install` novamente
- Tente `npm run build`

## 📞 Suporte

Para reportar bugs ou sugerir melhorias, abra uma issue no GitHub.

## 📄 Licença

Este projeto é privado. Todos os direitos reservados.

---

**Desenvolvido com ❤️ usando Next.js**
