// const mongoose = require('mongoose');
// const dns = require('node:dns/promises');
// dns.setServers(['1.1.1.1']);

// mongoose
//   .connect(
//     'mongodb+srv://bittrexglobalbuy:GfpE78XL6cZVhK3F@cluster0.cijuyrg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
//   )
//   .then(() => console.log('Conectou no MongoDB 🎉'))
//   .catch(err => console.error('Erro:', err));
